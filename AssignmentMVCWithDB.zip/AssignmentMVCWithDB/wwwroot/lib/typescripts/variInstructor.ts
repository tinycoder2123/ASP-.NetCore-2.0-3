﻿var variInstFlag: boolean[] = [false, false, false];

function checkinstructorform() {
    var cansubmit: boolean = true;
    for (var i = 0; i < 3; i++) {
        if (variInstFlag[i] == false) {
            cansubmit = false;
            break;
        }
    }
    if (cansubmit) {
        document.getElementById('submitbutton').removeAttribute("disabled");
    }
    else {
        document.getElementById('submitbutton').setAttribute("disabled", "false");
    }
}
function onfirstNameChanging(Text) {
    //alert(Text);
    if (Text.length > 0 && Text.length <= 10) {
        document.getElementById("firstNameMSG").innerHTML = "OK";
        variInstFlag[0] = true;
        checkinstructorform();
    }
    else {
        document.getElementById("firstNameMSG").innerHTML = "<div style='color: red'>Must be 10 characters or less, total</div>";
        variInstFlag[0] = false;
        checkinstructorform();
    }
}
function onlastNameChanging(Text) {
    if (Text.length > 0 && Text.length <= 10) {
        document.getElementById("lastNameMSG").innerHTML = "OK";
        variInstFlag[1] = true;
        checkinstructorform();
    }
    else {
        document.getElementById("lastNameMSG").innerHTML = "<div style='color: red'>Must be 10 characters or less, total</div>";
        variInstFlag[1] = false;
        checkinstructorform();
    }
}
function onTEmailChanging(Text) {
    if (Text.length > 0 && Text.length <= 30) {
        document.getElementById("TEmailMSG").innerHTML = "OK";
        variInstFlag[2] = true;
        checkinstructorform();
    }
    else {
        document.getElementById("TEmailMSG").innerHTML = "<div style='color: red'>Must be 30 characters or less, total</div>";
        variInstFlag[2] = false;
        checkinstructorform();
    }
}