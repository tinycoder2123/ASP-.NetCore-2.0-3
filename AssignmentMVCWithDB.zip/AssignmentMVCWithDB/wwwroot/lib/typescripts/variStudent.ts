﻿var variStudFlag: boolean[] = [false, false, false, false];

function checkstudentform() {
    var cansubmit: boolean = true;
    for (var i = 0; i < 3; i++) {
        if (variStudFlag[i] == false) {
            cansubmit = false;
            break;
        }
    }
    if (cansubmit) {
        document.getElementById('submitbutton').removeAttribute("disabled");
    }
    else {
        document.getElementById('submitbutton').setAttribute("disabled", "false");
    }
}
function onFirstNameChanging(Text) {
    //alert(Text);
    if (Text.length > 0 && Text.length <= 10) {
        document.getElementById("FirstNameMSG").innerHTML = "OK";
        variStudFlag[0] = true;
        checkstudentform();
    }
    else {
        document.getElementById("FirstNameMSG").innerHTML = "<div style='color: red'>Must be 10 characters or less, total</div>";
        variStudFlag[0] = false;
        checkstudentform();
    }
}
function onLastNameChanging(Text) {
    if (Text.length > 0 && Text.length <= 10) {
        document.getElementById("LastNameMSG").innerHTML = "OK";
        variStudFlag[1] = true;
        checkstudentform();
    }
    else {
        document.getElementById("LastNameMSG").innerHTML = "<div style='color: red'>Must be 10 characters or less, total</div>";
        variStudFlag[1] = false;
        checkstudentform();
    }
}
function onSEmailChanging(Text) {
    if (Text.length > 0 && Text.length <= 30) {
        document.getElementById("SEmailMSG").innerHTML = "OK";
        variStudFlag[2] = true;
        checkstudentform();
    }
    else {
        document.getElementById("SEmailMSG").innerHTML = "<div style='color: red'>Must be 30 characters or less, total</div>";
        variStudFlag[2] = false;
        checkstudentform();
    }
}
function onPhoneNumChanging(Text) {
    if (Text.length > 0 && Text.length <= 12) {
        document.getElementById("PhoneNumMSG").innerHTML = "OK";
        variStudFlag[3] = true;
        checkstudentform();
    }
    else {
        document.getElementById("PhoneNumMSG").innerHTML = "<div style='color: red'>Must be 12 characters or less, exp. ###-###-####, total</div>";
        variStudFlag[3] = false;
        checkstudentform();
    }
}