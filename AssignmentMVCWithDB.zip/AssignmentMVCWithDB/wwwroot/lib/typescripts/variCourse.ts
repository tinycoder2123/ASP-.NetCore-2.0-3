﻿var variCourseFlag: boolean[] = [false, false, false];

function checkcourseform()
{
    var cansubmit: boolean = true;
    for (var i = 0; i < 3; i++) {
        if (variCourseFlag[i] == false) {
            cansubmit = false;
            break;
        }
    }
    if (cansubmit)
    {
        document.getElementById('submitbutton').removeAttribute("disabled");
    }
    else
    {
        document.getElementById('submitbutton').setAttribute("disabled", "false");
    }
}
function onCourseNumChanging(Text)
{
    alert(Text);
    if (Text.length > 0 && Text.length <= 10) {
        document.getElementById("courseNumMSG").innerHTML = "OK";
        variCourseFlag[0] = true;
        checkcourseform();
    }
    else
    {
        document.getElementById("courseNumMSG").innerHTML = "<div style='color: red'>Must be 10 characters or less, total</div>";
        variCourseFlag[0] = false;
        checkcourseform();
    }
}
function onCourseNameChanging(Text) {
    if (Text.length > 0 && Text.length <= 10) {
        document.getElementById("courseNameMSG").innerHTML = "OK";
        variCourseFlag[1] = true;
        checkcourseform();
    }
    else {
        document.getElementById("courseNameMSG").innerHTML = "<div style='color: red'>Must be 10 characters or less, total</div>";
        variCourseFlag[1] = false;
        checkcourseform();
    }
}
function onCourseDesciptionChanging(Text) {
    if (Text.length > 0 && Text.length <= 50) {
        document.getElementById("courseDescriptionMSG").innerHTML = "OK";
        variCourseFlag[2] = true;
        checkcourseform();
    }
    else {
        document.getElementById("courseDescriptionMSG").innerHTML = "<div style='color: red'>Must be 50 characters or less, total</div>";
        variCourseFlag[2] = false;
        checkcourseform();
    }
}